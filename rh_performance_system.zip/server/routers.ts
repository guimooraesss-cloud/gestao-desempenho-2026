import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure, masterProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Positions (Cargos)
  positions: router({
    list: protectedProcedure.query(() => db.getAllPositions()),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getPositionById(input.id)),
    create: masterProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        requirements: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return { success: true };
      }),
  }),

  // Competencies
  competencies: router({
    list: protectedProcedure.query(() => db.getAllCompetencies()),
    getById: protectedProcedure.input(z.object({ id: z.number() })).query(({ input }) => db.getCompetencyById(input.id)),
    getByCategory: protectedProcedure
      .input(z.object({ category: z.string() }))
      .query(({ input }) => db.getCompetenciesByCategory(input.category)),
    create: masterProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        category: z.enum([
          "Cultural/Core",
          "Soft Skill (Atitude)",
          "Soft Skill (Relacional)",
          "Soft Skill (Distintiva)",
          "Hard Skill (Técnica)",
          "Results Skill",
          "Liderança"
        ]),
      }))
      .mutation(async ({ input }) => {
        return { success: true };
      }),
  }),

  // Employees
  employees: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role === "master") {
        return await db.getAllEmployees();
      }
      return [];
    }),
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const employee = await db.getEmployeeById(input.id);
        if (!employee) return null;
        if (ctx.user?.role === "master") return employee;
        return null;
      }),
  }),
});

export type AppRouter = typeof appRouter;
